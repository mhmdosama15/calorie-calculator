import * as universal from "../../../../src/routes/pp/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/pp/+page.svelte";