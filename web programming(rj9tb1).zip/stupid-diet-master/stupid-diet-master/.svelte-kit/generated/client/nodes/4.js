import * as universal from "../../../../src/routes/contact/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/contact/+page.svelte";