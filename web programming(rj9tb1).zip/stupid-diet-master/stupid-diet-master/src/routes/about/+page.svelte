<svelte:head>
	<title>About</title>
	<meta name="description" content="About Stupid Diet" />
</svelte:head>

<div class="text-column">
	<h1>About Stupid Diet</h1>

	<p>
		This is a <b>Stupid Diet</b> app. You can easily calculate your base calories.
	</p>

	<p>We're also working on more apps to help you reach your health goals.</p>
</div>
