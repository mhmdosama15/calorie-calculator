<svelte:head>
	<title>Contact</title>
	<meta name="description" content="Contact" />
</svelte:head>

<div class="text-column">
	<h1>Contact or Support for Stupid-Diet and Kalory app</h1>

	<p>Please message us at stupiddiet@gmail.com</p>
</div>
